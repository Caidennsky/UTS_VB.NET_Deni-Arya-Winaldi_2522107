﻿Public Class Form1
    Dim Total, Bayar, Kembali As Double
    Dim CBItem As CheckBox()
    Dim THarga As TextBox()
    Dim TJumlah As TextBox()


    Private Sub Thitung_Click(sender As Object, e As EventArgs) Handles Thitung.Click
        Dim i As Integer
        Total = 0
        For i = 0 To 8
            If CBItem(i).Checked = True Then
                Total = Total + Val(THarga(i).Text) * Val(TJumlah(i).Text)
            End If
        Next
        Ttotal.Text = "Rp. " & Format(Total, "#,#.##")
    End Sub

    Private Sub Tbayar_TextChanged(sender As Object, e As EventArgs) Handles Tbayar.TextChanged

    End Sub



    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CBItem = New CheckBox() {ma1, ma2, ma3, mi1, mi2, mi3, me1, me2, me3}
        THarga = New TextBox() {mat1, mat2, mat3, mit1, mit2, mit3, met1, met2, met3}
        TJumlah = New TextBox() {maj1, maj2, maj3, mij1, mij2, mij3, mej1, mej2, mej3}
    End Sub

    Private Sub Tbayar_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Tbayar.KeyPress
        If e.KeyChar = Chr(13) Then
            Bayar = Val(Tbayar.Text)
            Kembali = Bayar - Total
            Tkembali.Text = "Rp. " & Format(Kembali, "#,#.##")
        End If
    End Sub
End Class
