﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.maj3 = New System.Windows.Forms.TextBox()
        Me.maj2 = New System.Windows.Forms.TextBox()
        Me.maj1 = New System.Windows.Forms.TextBox()
        Me.mat3 = New System.Windows.Forms.TextBox()
        Me.mat2 = New System.Windows.Forms.TextBox()
        Me.mat1 = New System.Windows.Forms.TextBox()
        Me.ma3 = New System.Windows.Forms.CheckBox()
        Me.ma2 = New System.Windows.Forms.CheckBox()
        Me.ma1 = New System.Windows.Forms.CheckBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.mij3 = New System.Windows.Forms.TextBox()
        Me.mij2 = New System.Windows.Forms.TextBox()
        Me.mij1 = New System.Windows.Forms.TextBox()
        Me.mit3 = New System.Windows.Forms.TextBox()
        Me.mit2 = New System.Windows.Forms.TextBox()
        Me.mit1 = New System.Windows.Forms.TextBox()
        Me.mi3 = New System.Windows.Forms.CheckBox()
        Me.mi2 = New System.Windows.Forms.CheckBox()
        Me.mi1 = New System.Windows.Forms.CheckBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.mej3 = New System.Windows.Forms.TextBox()
        Me.mej2 = New System.Windows.Forms.TextBox()
        Me.mej1 = New System.Windows.Forms.TextBox()
        Me.met3 = New System.Windows.Forms.TextBox()
        Me.met2 = New System.Windows.Forms.TextBox()
        Me.met1 = New System.Windows.Forms.TextBox()
        Me.me3 = New System.Windows.Forms.CheckBox()
        Me.me2 = New System.Windows.Forms.CheckBox()
        Me.me1 = New System.Windows.Forms.CheckBox()
        Me.PictureBox10 = New System.Windows.Forms.PictureBox()
        Me.PictureBox9 = New System.Windows.Forms.PictureBox()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Ttotal = New System.Windows.Forms.TextBox()
        Me.Tbayar = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Tkembali = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Thitung = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Freestyle Script", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(187, 32)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(414, 58)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Gratis Ongkir Semua Variant"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(193, 94)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(320, 24)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Untuk Wilayah Bukik Dan Sekitar"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(834, 55)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(338, 24)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Nama : Caidenn(Deni Arya Winaldi)"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(834, 94)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(142, 24)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Nim : 2522107"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.maj3)
        Me.GroupBox1.Controls.Add(Me.maj2)
        Me.GroupBox1.Controls.Add(Me.maj1)
        Me.GroupBox1.Controls.Add(Me.mat3)
        Me.GroupBox1.Controls.Add(Me.mat2)
        Me.GroupBox1.Controls.Add(Me.mat1)
        Me.GroupBox1.Controls.Add(Me.ma3)
        Me.GroupBox1.Controls.Add(Me.ma2)
        Me.GroupBox1.Controls.Add(Me.ma1)
        Me.GroupBox1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.White
        Me.GroupBox1.Location = New System.Drawing.Point(113, 188)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(449, 259)
        Me.GroupBox1.TabIndex = 8
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Makanan"
        '
        'maj3
        '
        Me.maj3.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.maj3.Location = New System.Drawing.Point(382, 207)
        Me.maj3.Name = "maj3"
        Me.maj3.Size = New System.Drawing.Size(41, 35)
        Me.maj3.TabIndex = 11
        Me.maj3.Text = "0"
        Me.maj3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'maj2
        '
        Me.maj2.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.maj2.Location = New System.Drawing.Point(382, 132)
        Me.maj2.Name = "maj2"
        Me.maj2.Size = New System.Drawing.Size(41, 35)
        Me.maj2.TabIndex = 10
        Me.maj2.Text = "0"
        Me.maj2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'maj1
        '
        Me.maj1.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.maj1.Location = New System.Drawing.Point(382, 52)
        Me.maj1.Name = "maj1"
        Me.maj1.Size = New System.Drawing.Size(41, 35)
        Me.maj1.TabIndex = 9
        Me.maj1.Text = "0"
        Me.maj1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'mat3
        '
        Me.mat3.Location = New System.Drawing.Point(189, 205)
        Me.mat3.Name = "mat3"
        Me.mat3.Size = New System.Drawing.Size(168, 35)
        Me.mat3.TabIndex = 5
        Me.mat3.Text = "14000"
        '
        'mat2
        '
        Me.mat2.Location = New System.Drawing.Point(192, 132)
        Me.mat2.Name = "mat2"
        Me.mat2.Size = New System.Drawing.Size(168, 35)
        Me.mat2.TabIndex = 4
        Me.mat2.Text = "12000"
        '
        'mat1
        '
        Me.mat1.Location = New System.Drawing.Point(192, 52)
        Me.mat1.Name = "mat1"
        Me.mat1.Size = New System.Drawing.Size(168, 35)
        Me.mat1.TabIndex = 3
        Me.mat1.Text = "14000"
        '
        'ma3
        '
        Me.ma3.AutoSize = True
        Me.ma3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ma3.Location = New System.Drawing.Point(7, 217)
        Me.ma3.Name = "ma3"
        Me.ma3.Size = New System.Drawing.Size(136, 23)
        Me.ma3.TabIndex = 2
        Me.ma3.Text = "Ayam Geprek"
        Me.ma3.UseVisualStyleBackColor = True
        '
        'ma2
        '
        Me.ma2.AutoSize = True
        Me.ma2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ma2.Location = New System.Drawing.Point(7, 132)
        Me.ma2.Name = "ma2"
        Me.ma2.Size = New System.Drawing.Size(105, 23)
        Me.ma2.TabIndex = 1
        Me.ma2.Text = "Rendang"
        Me.ma2.UseVisualStyleBackColor = True
        '
        'ma1
        '
        Me.ma1.AutoSize = True
        Me.ma1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ma1.Location = New System.Drawing.Point(7, 52)
        Me.ma1.Name = "ma1"
        Me.ma1.Size = New System.Drawing.Size(126, 23)
        Me.ma1.TabIndex = 0
        Me.ma1.Text = "Ayam Bakar"
        Me.ma1.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.mij3)
        Me.GroupBox2.Controls.Add(Me.mij2)
        Me.GroupBox2.Controls.Add(Me.mij1)
        Me.GroupBox2.Controls.Add(Me.mit3)
        Me.GroupBox2.Controls.Add(Me.mit2)
        Me.GroupBox2.Controls.Add(Me.mit1)
        Me.GroupBox2.Controls.Add(Me.mi3)
        Me.GroupBox2.Controls.Add(Me.mi2)
        Me.GroupBox2.Controls.Add(Me.mi1)
        Me.GroupBox2.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.Color.White
        Me.GroupBox2.Location = New System.Drawing.Point(113, 464)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(449, 259)
        Me.GroupBox2.TabIndex = 12
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Minuman"
        '
        'mij3
        '
        Me.mij3.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mij3.Location = New System.Drawing.Point(382, 207)
        Me.mij3.Name = "mij3"
        Me.mij3.Size = New System.Drawing.Size(41, 35)
        Me.mij3.TabIndex = 11
        Me.mij3.Text = "0"
        Me.mij3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'mij2
        '
        Me.mij2.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mij2.Location = New System.Drawing.Point(382, 132)
        Me.mij2.Name = "mij2"
        Me.mij2.Size = New System.Drawing.Size(41, 35)
        Me.mij2.TabIndex = 10
        Me.mij2.Text = "0"
        Me.mij2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'mij1
        '
        Me.mij1.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mij1.Location = New System.Drawing.Point(382, 52)
        Me.mij1.Name = "mij1"
        Me.mij1.Size = New System.Drawing.Size(41, 35)
        Me.mij1.TabIndex = 9
        Me.mij1.Text = "0"
        Me.mij1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'mit3
        '
        Me.mit3.Location = New System.Drawing.Point(192, 205)
        Me.mit3.Name = "mit3"
        Me.mit3.Size = New System.Drawing.Size(168, 35)
        Me.mit3.TabIndex = 5
        Me.mit3.Text = "5000"
        '
        'mit2
        '
        Me.mit2.Location = New System.Drawing.Point(192, 132)
        Me.mit2.Name = "mit2"
        Me.mit2.Size = New System.Drawing.Size(168, 35)
        Me.mit2.TabIndex = 4
        Me.mit2.Text = "5000"
        '
        'mit1
        '
        Me.mit1.Location = New System.Drawing.Point(192, 52)
        Me.mit1.Name = "mit1"
        Me.mit1.Size = New System.Drawing.Size(168, 35)
        Me.mit1.TabIndex = 3
        Me.mit1.Text = "5000"
        '
        'mi3
        '
        Me.mi3.AutoSize = True
        Me.mi3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mi3.Location = New System.Drawing.Point(7, 217)
        Me.mi3.Name = "mi3"
        Me.mi3.Size = New System.Drawing.Size(168, 23)
        Me.mi3.TabIndex = 2
        Me.mi3.Text = "Es Nutrisari Susu"
        Me.mi3.UseVisualStyleBackColor = True
        '
        'mi2
        '
        Me.mi2.AutoSize = True
        Me.mi2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mi2.Location = New System.Drawing.Point(7, 132)
        Me.mi2.Name = "mi2"
        Me.mi2.Size = New System.Drawing.Size(91, 23)
        Me.mi2.TabIndex = 1
        Me.mi2.Text = "Es milo"
        Me.mi2.UseVisualStyleBackColor = True
        '
        'mi1
        '
        Me.mi1.AutoSize = True
        Me.mi1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mi1.Location = New System.Drawing.Point(7, 52)
        Me.mi1.Name = "mi1"
        Me.mi1.Size = New System.Drawing.Size(166, 23)
        Me.mi1.TabIndex = 0
        Me.mi1.Text = "Teh Manis Dingin"
        Me.mi1.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.mej3)
        Me.GroupBox3.Controls.Add(Me.mej2)
        Me.GroupBox3.Controls.Add(Me.mej1)
        Me.GroupBox3.Controls.Add(Me.met3)
        Me.GroupBox3.Controls.Add(Me.met2)
        Me.GroupBox3.Controls.Add(Me.met1)
        Me.GroupBox3.Controls.Add(Me.me3)
        Me.GroupBox3.Controls.Add(Me.me2)
        Me.GroupBox3.Controls.Add(Me.me1)
        Me.GroupBox3.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.ForeColor = System.Drawing.Color.White
        Me.GroupBox3.Location = New System.Drawing.Point(704, 188)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(449, 259)
        Me.GroupBox3.TabIndex = 12
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Mie"
        '
        'mej3
        '
        Me.mej3.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mej3.Location = New System.Drawing.Point(382, 207)
        Me.mej3.Name = "mej3"
        Me.mej3.Size = New System.Drawing.Size(41, 35)
        Me.mej3.TabIndex = 11
        Me.mej3.Text = "0"
        Me.mej3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'mej2
        '
        Me.mej2.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mej2.Location = New System.Drawing.Point(382, 132)
        Me.mej2.Name = "mej2"
        Me.mej2.Size = New System.Drawing.Size(41, 35)
        Me.mej2.TabIndex = 10
        Me.mej2.Text = "0"
        Me.mej2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'mej1
        '
        Me.mej1.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mej1.Location = New System.Drawing.Point(382, 52)
        Me.mej1.Name = "mej1"
        Me.mej1.Size = New System.Drawing.Size(41, 35)
        Me.mej1.TabIndex = 9
        Me.mej1.Text = "0"
        Me.mej1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'met3
        '
        Me.met3.Location = New System.Drawing.Point(189, 205)
        Me.met3.Name = "met3"
        Me.met3.Size = New System.Drawing.Size(168, 35)
        Me.met3.TabIndex = 5
        Me.met3.Text = "14000"
        '
        'met2
        '
        Me.met2.Location = New System.Drawing.Point(192, 132)
        Me.met2.Name = "met2"
        Me.met2.Size = New System.Drawing.Size(168, 35)
        Me.met2.TabIndex = 4
        Me.met2.Text = "12000"
        '
        'met1
        '
        Me.met1.Location = New System.Drawing.Point(192, 52)
        Me.met1.Name = "met1"
        Me.met1.Size = New System.Drawing.Size(168, 35)
        Me.met1.TabIndex = 3
        Me.met1.Text = "12000"
        '
        'me3
        '
        Me.me3.AutoSize = True
        Me.me3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.me3.Location = New System.Drawing.Point(7, 217)
        Me.me3.Name = "me3"
        Me.me3.Size = New System.Drawing.Size(165, 23)
        Me.me3.TabIndex = 2
        Me.me3.Text = "Kwetiau Seafood"
        Me.me3.UseVisualStyleBackColor = True
        '
        'me2
        '
        Me.me2.AutoSize = True
        Me.me2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.me2.Location = New System.Drawing.Point(7, 132)
        Me.me2.Name = "me2"
        Me.me2.Size = New System.Drawing.Size(113, 23)
        Me.me2.TabIndex = 1
        Me.me2.Text = "Mie Pedas"
        Me.me2.UseVisualStyleBackColor = True
        '
        'me1
        '
        Me.me1.AutoSize = True
        Me.me1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.me1.Location = New System.Drawing.Point(7, 52)
        Me.me1.Name = "me1"
        Me.me1.Size = New System.Drawing.Size(122, 23)
        Me.me1.TabIndex = 0
        Me.me1.Text = "Mie Goreng"
        Me.me1.UseVisualStyleBackColor = True
        '
        'PictureBox10
        '
        Me.PictureBox10.Image = Global.pert_6.My.Resources.Resources.kwetiau_seafood
        Me.PictureBox10.Location = New System.Drawing.Point(603, 372)
        Me.PictureBox10.Name = "PictureBox10"
        Me.PictureBox10.Size = New System.Drawing.Size(95, 75)
        Me.PictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox10.TabIndex = 18
        Me.PictureBox10.TabStop = False
        '
        'PictureBox9
        '
        Me.PictureBox9.Image = Global.pert_6.My.Resources.Resources.mipadeh
        Me.PictureBox9.Location = New System.Drawing.Point(603, 291)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(95, 75)
        Me.PictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox9.TabIndex = 17
        Me.PictureBox9.TabStop = False
        '
        'PictureBox8
        '
        Me.PictureBox8.Image = Global.pert_6.My.Resources.Resources.mi_goreng
        Me.PictureBox8.Location = New System.Drawing.Point(603, 202)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(95, 75)
        Me.PictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox8.TabIndex = 16
        Me.PictureBox8.TabStop = False
        '
        'PictureBox7
        '
        Me.PictureBox7.Image = Global.pert_6.My.Resources.Resources.nutrisari
        Me.PictureBox7.Location = New System.Drawing.Point(12, 638)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(95, 75)
        Me.PictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox7.TabIndex = 15
        Me.PictureBox7.TabStop = False
        '
        'PictureBox6
        '
        Me.PictureBox6.Image = Global.pert_6.My.Resources.Resources.milo
        Me.PictureBox6.Location = New System.Drawing.Point(12, 557)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(95, 75)
        Me.PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox6.TabIndex = 14
        Me.PictureBox6.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.Image = Global.pert_6.My.Resources.Resources.mandi
        Me.PictureBox5.Location = New System.Drawing.Point(12, 476)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(95, 75)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox5.TabIndex = 13
        Me.PictureBox5.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.Image = Global.pert_6.My.Resources.Resources.ayamgprk
        Me.PictureBox4.Location = New System.Drawing.Point(12, 372)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(95, 75)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox4.TabIndex = 7
        Me.PictureBox4.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = Global.pert_6.My.Resources.Resources.Resep_Rendang_Daging_Sapi_Untuk_Lebaran_Gurih_dan_Nikmat
        Me.PictureBox3.Location = New System.Drawing.Point(12, 292)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(95, 74)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox3.TabIndex = 6
        Me.PictureBox3.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.pert_6.My.Resources.Resources.ayambaka
        Me.PictureBox2.Location = New System.Drawing.Point(12, 202)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(95, 84)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 5
        Me.PictureBox2.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.pert_6.My.Resources.Resources.logo
        Me.PictureBox1.Location = New System.Drawing.Point(12, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(150, 150)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(694, 548)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(76, 24)
        Me.Label5.TabIndex = 19
        Me.Label5.Text = "TOTAL"
        '
        'Ttotal
        '
        Me.Ttotal.Location = New System.Drawing.Point(798, 546)
        Me.Ttotal.Name = "Ttotal"
        Me.Ttotal.Size = New System.Drawing.Size(226, 26)
        Me.Ttotal.TabIndex = 20
        '
        'Tbayar
        '
        Me.Tbayar.Location = New System.Drawing.Point(798, 593)
        Me.Tbayar.Name = "Tbayar"
        Me.Tbayar.Size = New System.Drawing.Size(226, 26)
        Me.Tbayar.TabIndex = 22
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(694, 595)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(73, 24)
        Me.Label6.TabIndex = 21
        Me.Label6.Text = "BAYAR"
        '
        'Tkembali
        '
        Me.Tkembali.BackColor = System.Drawing.Color.Gray
        Me.Tkembali.Location = New System.Drawing.Point(798, 640)
        Me.Tkembali.Name = "Tkembali"
        Me.Tkembali.Size = New System.Drawing.Size(226, 26)
        Me.Tkembali.TabIndex = 24
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(694, 640)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(98, 24)
        Me.Label7.TabIndex = 23
        Me.Label7.Text = "KEMBALI"
        '
        'Thitung
        '
        Me.Thitung.BackColor = System.Drawing.Color.Salmon
        Me.Thitung.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Thitung.Location = New System.Drawing.Point(798, 485)
        Me.Thitung.Name = "Thitung"
        Me.Thitung.Size = New System.Drawing.Size(226, 44)
        Me.Thitung.TabIndex = 25
        Me.Thitung.Text = "HITUNG"
        Me.Thitung.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Salmon
        Me.ClientSize = New System.Drawing.Size(1180, 740)
        Me.Controls.Add(Me.Thitung)
        Me.Controls.Add(Me.Tkembali)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Tbayar)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Ttotal)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.PictureBox10)
        Me.Controls.Add(Me.PictureBox9)
        Me.Controls.Add(Me.PictureBox8)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.PictureBox7)
        Me.Controls.Add(Me.PictureBox6)
        Me.Controls.Add(Me.PictureBox5)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents maj3 As TextBox
    Friend WithEvents maj2 As TextBox
    Friend WithEvents maj1 As TextBox
    Friend WithEvents mat3 As TextBox
    Friend WithEvents mat2 As TextBox
    Friend WithEvents mat1 As TextBox
    Friend WithEvents ma3 As CheckBox
    Friend WithEvents ma2 As CheckBox
    Friend WithEvents ma1 As CheckBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents mij3 As TextBox
    Friend WithEvents mij2 As TextBox
    Friend WithEvents mij1 As TextBox
    Friend WithEvents mit3 As TextBox
    Friend WithEvents mit2 As TextBox
    Friend WithEvents mit1 As TextBox
    Friend WithEvents mi3 As CheckBox
    Friend WithEvents mi2 As CheckBox
    Friend WithEvents mi1 As CheckBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents mej3 As TextBox
    Friend WithEvents mej2 As TextBox
    Friend WithEvents mej1 As TextBox
    Friend WithEvents met3 As TextBox
    Friend WithEvents met2 As TextBox
    Friend WithEvents met1 As TextBox
    Friend WithEvents me3 As CheckBox
    Friend WithEvents me2 As CheckBox
    Friend WithEvents me1 As CheckBox
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents PictureBox9 As PictureBox
    Friend WithEvents PictureBox10 As PictureBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Ttotal As TextBox
    Friend WithEvents Tbayar As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Tkembali As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Thitung As Button
End Class
