﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Nbarang = New System.Windows.Forms.TextBox()
        Me.Hsatuan = New System.Windows.Forms.TextBox()
        Me.Jitem = New System.Windows.Forms.TextBox()
        Me.Tbonus = New System.Windows.Forms.TextBox()
        Me.Tharga = New System.Windows.Forms.TextBox()
        Me.Tdiskon = New System.Windows.Forms.TextBox()
        Me.Tbayar = New System.Windows.Forms.TextBox()
        Me.Reset = New System.Windows.Forms.Button()
        Me.Tutup = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(13, 28)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(171, 29)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Nama Barang"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(16, 307)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(86, 29)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Bonus"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(13, 116)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(153, 29)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Jumlah Item"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(16, 263)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(146, 29)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Total Bayar"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(13, 72)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(170, 29)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Harga Satuan"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(16, 184)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(150, 29)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Total Harga"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(16, 223)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(93, 29)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Diskon"
        '
        'Nbarang
        '
        Me.Nbarang.Location = New System.Drawing.Point(223, 30)
        Me.Nbarang.Name = "Nbarang"
        Me.Nbarang.Size = New System.Drawing.Size(252, 26)
        Me.Nbarang.TabIndex = 7
        '
        'Hsatuan
        '
        Me.Hsatuan.Location = New System.Drawing.Point(223, 76)
        Me.Hsatuan.Name = "Hsatuan"
        Me.Hsatuan.Size = New System.Drawing.Size(185, 26)
        Me.Hsatuan.TabIndex = 8
        '
        'Jitem
        '
        Me.Jitem.Location = New System.Drawing.Point(223, 120)
        Me.Jitem.Name = "Jitem"
        Me.Jitem.Size = New System.Drawing.Size(185, 26)
        Me.Jitem.TabIndex = 9
        '
        'Tbonus
        '
        Me.Tbonus.Location = New System.Drawing.Point(223, 310)
        Me.Tbonus.Name = "Tbonus"
        Me.Tbonus.Size = New System.Drawing.Size(185, 26)
        Me.Tbonus.TabIndex = 10
        '
        'Tharga
        '
        Me.Tharga.Location = New System.Drawing.Point(223, 188)
        Me.Tharga.Name = "Tharga"
        Me.Tharga.Size = New System.Drawing.Size(185, 26)
        Me.Tharga.TabIndex = 11
        '
        'Tdiskon
        '
        Me.Tdiskon.Location = New System.Drawing.Point(223, 227)
        Me.Tdiskon.Name = "Tdiskon"
        Me.Tdiskon.Size = New System.Drawing.Size(185, 26)
        Me.Tdiskon.TabIndex = 12
        '
        'Tbayar
        '
        Me.Tbayar.Location = New System.Drawing.Point(223, 267)
        Me.Tbayar.Name = "Tbayar"
        Me.Tbayar.Size = New System.Drawing.Size(185, 26)
        Me.Tbayar.TabIndex = 13
        '
        'Reset
        '
        Me.Reset.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Reset.Location = New System.Drawing.Point(453, 120)
        Me.Reset.Name = "Reset"
        Me.Reset.Size = New System.Drawing.Size(86, 39)
        Me.Reset.TabIndex = 14
        Me.Reset.Text = "Reset"
        Me.Reset.UseVisualStyleBackColor = True
        '
        'Tutup
        '
        Me.Tutup.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tutup.Location = New System.Drawing.Point(259, 356)
        Me.Tutup.Name = "Tutup"
        Me.Tutup.Size = New System.Drawing.Size(120, 44)
        Me.Tutup.TabIndex = 15
        Me.Tutup.Text = "Tutup"
        Me.Tutup.UseVisualStyleBackColor = True
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Salmon
        Me.ClientSize = New System.Drawing.Size(738, 412)
        Me.Controls.Add(Me.Tutup)
        Me.Controls.Add(Me.Reset)
        Me.Controls.Add(Me.Tbayar)
        Me.Controls.Add(Me.Tdiskon)
        Me.Controls.Add(Me.Tharga)
        Me.Controls.Add(Me.Tbonus)
        Me.Controls.Add(Me.Jitem)
        Me.Controls.Add(Me.Hsatuan)
        Me.Controls.Add(Me.Nbarang)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form2"
        Me.Text = "Program Belanja"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Nbarang As TextBox
    Friend WithEvents Hsatuan As TextBox
    Friend WithEvents Jitem As TextBox
    Friend WithEvents Tbonus As TextBox
    Friend WithEvents Tharga As TextBox
    Friend WithEvents Tdiskon As TextBox
    Friend WithEvents Tbayar As TextBox
    Friend WithEvents Reset As Button
    Friend WithEvents Tutup As Button
End Class
