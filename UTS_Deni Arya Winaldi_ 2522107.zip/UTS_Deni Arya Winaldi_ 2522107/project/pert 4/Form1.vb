﻿Public Class Form1

    Dim Nilai As Integer
    Dim Keterangan, Ucapan As String

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Nilai = 60
        Keterangan = "lulus"
        If Nilai >= 60 Then
            MsgBox(Keterangan)
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Nilai = 40
        If Nilai >= 60 Then
            Keterangan = "lulus"
        Else
            Keterangan = "tidak lulus"
        End If
        MsgBox(Keterangan)
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Nilai = 60
        If Nilai >= 85 Then
            Keterangan = "lulus,sangat memuaskan"
        ElseIf Nilai >= 70 Then
            Keterangan = "lulus,memuaskan"
        ElseIf Nilai >= 60 Then
            Keterangan = "lulus,kurang"
        Else
            Keterangan = "tidak lulus"
        End If

        MsgBox(Keterangan)
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click

    End Sub

    Private Sub ComboBox2_SelectedIndexChanged(sender As Object, e As EventArgs)
        Select Case ComboBox1.Text
            Case "satu"
                Keterangan = ComboBox1.Text
        End Select
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Nilai = 60
        If Nilai >= 60 Then
            Keterangan = "lulus"
            Ucapan = "selamat anda : "
            MsgBox(Ucapan + Keterangan)
        End If
    End Sub
End Class
