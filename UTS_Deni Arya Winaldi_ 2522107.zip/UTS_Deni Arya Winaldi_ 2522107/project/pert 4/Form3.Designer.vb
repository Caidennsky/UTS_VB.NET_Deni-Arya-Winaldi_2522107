﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.ListHosting = New System.Windows.Forms.ComboBox()
        Me.THargaHosting = New System.Windows.Forms.TextBox()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.ListDomain = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.THargaDomain = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.BtnKeluar = New System.Windows.Forms.Button()
        Me.BtnHitung = New System.Windows.Forms.Button()
        Me.TMasaAktif = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TjumlahBayar = New System.Windows.Forms.TextBox()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(357, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(153, 26)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Hosting Murah"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(325, 50)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(210, 32)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Caidenn Store"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(236, 104)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(397, 26)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "-------------------------------------------------------"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(47, 170)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(148, 26)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Paket Hosting"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(506, 170)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(151, 26)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Harga Hosting"
        '
        'ListHosting
        '
        Me.ListHosting.FormattingEnabled = True
        Me.ListHosting.Items.AddRange(New Object() {"ENTRY", "SMALL", "MEDIUM", "LARGE"})
        Me.ListHosting.Location = New System.Drawing.Point(52, 199)
        Me.ListHosting.Name = "ListHosting"
        Me.ListHosting.Size = New System.Drawing.Size(309, 28)
        Me.ListHosting.TabIndex = 5
        Me.ListHosting.Text = "List Hosting"
        '
        'THargaHosting
        '
        Me.THargaHosting.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.THargaHosting.Location = New System.Drawing.Point(511, 199)
        Me.THargaHosting.Name = "THargaHosting"
        Me.THargaHosting.Size = New System.Drawing.Size(171, 26)
        Me.THargaHosting.TabIndex = 6
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(52, 234)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(164, 24)
        Me.CheckBox1.TabIndex = 7
        Me.CheckBox1.Text = "Termasuk Domain"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(47, 270)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(166, 26)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "Extensi Domain"
        '
        'ListDomain
        '
        Me.ListDomain.AccessibleName = ""
        Me.ListDomain.FormattingEnabled = True
        Me.ListDomain.Items.AddRange(New Object() {".COM", ".ID", ".ORG", ".SCH", ".AC.ID"})
        Me.ListDomain.Location = New System.Drawing.Point(52, 299)
        Me.ListDomain.Name = "ListDomain"
        Me.ListDomain.Size = New System.Drawing.Size(309, 28)
        Me.ListDomain.TabIndex = 9
        Me.ListDomain.Text = "List Domain"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(506, 270)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(153, 26)
        Me.Label7.TabIndex = 10
        Me.Label7.Text = "Harga Domain"
        '
        'THargaDomain
        '
        Me.THargaDomain.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.THargaDomain.Location = New System.Drawing.Point(511, 301)
        Me.THargaDomain.Name = "THargaDomain"
        Me.THargaDomain.Size = New System.Drawing.Size(171, 26)
        Me.THargaDomain.TabIndex = 11
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.BtnKeluar)
        Me.GroupBox1.Controls.Add(Me.BtnHitung)
        Me.GroupBox1.Controls.Add(Me.TMasaAktif)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Location = New System.Drawing.Point(52, 365)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(630, 311)
        Me.GroupBox1.TabIndex = 12
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Perhitungan Tagihan"
        '
        'BtnKeluar
        '
        Me.BtnKeluar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnKeluar.Location = New System.Drawing.Point(256, 252)
        Me.BtnKeluar.Name = "BtnKeluar"
        Me.BtnKeluar.Size = New System.Drawing.Size(93, 39)
        Me.BtnKeluar.TabIndex = 16
        Me.BtnKeluar.Text = "Keluar"
        Me.BtnKeluar.UseVisualStyleBackColor = True
        '
        'BtnHitung
        '
        Me.BtnHitung.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnHitung.Location = New System.Drawing.Point(408, 63)
        Me.BtnHitung.Name = "BtnHitung"
        Me.BtnHitung.Size = New System.Drawing.Size(93, 39)
        Me.BtnHitung.TabIndex = 15
        Me.BtnHitung.Text = "Hitung"
        Me.BtnHitung.UseVisualStyleBackColor = True
        '
        'TMasaAktif
        '
        Me.TMasaAktif.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TMasaAktif.Location = New System.Drawing.Point(44, 76)
        Me.TMasaAktif.Name = "TMasaAktif"
        Me.TMasaAktif.Size = New System.Drawing.Size(334, 26)
        Me.TMasaAktif.TabIndex = 13
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(39, 122)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(146, 26)
        Me.Label9.TabIndex = 14
        Me.Label9.Text = "Jumlah Bayar"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(39, 47)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(190, 26)
        Me.Label8.TabIndex = 13
        Me.Label8.Text = " Masa Aktif(Bulan)"
        '
        'TjumlahBayar
        '
        Me.TjumlahBayar.Font = New System.Drawing.Font("Microsoft Sans Serif", 28.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TjumlahBayar.Location = New System.Drawing.Point(96, 516)
        Me.TjumlahBayar.Name = "TjumlahBayar"
        Me.TjumlahBayar.Size = New System.Drawing.Size(457, 71)
        Me.TjumlahBayar.TabIndex = 15
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Salmon
        Me.ClientSize = New System.Drawing.Size(842, 706)
        Me.Controls.Add(Me.TjumlahBayar)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.THargaDomain)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.ListDomain)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.CheckBox1)
        Me.Controls.Add(Me.THargaHosting)
        Me.Controls.Add(Me.ListHosting)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form3"
        Me.Text = "Order Hosting"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents ListHosting As ComboBox
    Friend WithEvents THargaHosting As TextBox
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents Label6 As Label
    Friend WithEvents ListDomain As ComboBox
    Friend WithEvents Label7 As Label
    Friend WithEvents THargaDomain As TextBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents TMasaAktif As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents BtnKeluar As Button
    Friend WithEvents BtnHitung As Button
    Friend WithEvents TjumlahBayar As TextBox
End Class
